import React, { Component } from 'react'

class HeaderComponent extends Component {
    constructor(props) {
        super(props)

        this.state = {
                 
        }
        this.home = this.home.bind(this);
        this.ProductList = this.ProductList.bind(this);
        this.cart = this.cart.bind(this);
    }

    home(){
        this.props.history.push('/');
    }

    ProductList(){
        this.props.history.push('/products');
    }

    cart(){
        this.props.history.push('/cart');
    }

    render() {
        return (
            <div>
                <header>
                    <nav className="navbar navbar-expand-md navbar-dark bg-dark">
                    {/*<div><a href="https://google.com" className="navbar-brand">E-Commerce App</a></div> */}
                    <div><a href= "/" className="navbar-brand">E-Commerce App</a></div>
                    <div className = "row">
                    <button className="btn btn-primary" onClick={this.home}> Home</button>
                     <button className="btn btn-primary" onClick={this.ProductList}> Product List</button>
                     <button className="btn btn-primary" onClick={this.cart}> Cart</button>

                    </div>
                    </nav>
                </header>
            </div>
        )
    }
}

export default HeaderComponent
