import React, { Component } from 'react';
import CartService from '../services/CartService'

class Cart extends Component {
    constructor(props) {
        super(props)

        this.state = {
                cart: []
        }
    }

    componentDidMount(){
        CartService.getProducts().then((res) => {
            this.setState({cart: res.data});
        });
    }

    render() {
        return (
            <div>
                 <h2 className="text-center">Cart</h2>
                 <div className = "row">
                    <button className="btn btn-primary" onClick={this.addProduct}> Add Product</button>
                 </div>
                 <div className = "row">
                    <button className="btn btn-primary" onClick={this.addProduct}> Cart</button>
                 </div>
                 <br></br>
                 <div className = "row">
                        <table className = "table table-striped table-bordered">

                            <thead>
                                <tr>
                                    <th> Product Name</th>
                                    <th> Product Price</th>
                                    <th> Product Description</th>
                                    <th> Quantity</th>
                                    <th> Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                {
                                    this.state.cart.map(
                                        cart => 
                                        <tr key = {cart.id}>
                                             <td> {cart.productName} </td>   
                                             <td> {cart.productPrice}</td>
                                             <td> {cart.description}</td>
                                             <td> {cart.quantity}</td>
                                             <td>
                                                 <button onClick={ () => this.editProduct(cart.id)} className="btn btn-info">Update </button>
                                                 <button style={{marginLeft: "10px"}} onClick={ () => this.deleteProduct(cart.id)} className="btn btn-danger">Delete </button>
                                            </td>
                                        </tr>
                                    )
                                }
                            </tbody>
                        </table>
                    </div>

                
            </div>
        );
    }
}

export default Cart;