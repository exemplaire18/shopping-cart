import React, { Component } from 'react'
import CartService from '../services/CartService';
import ProductService from '../services/ProductService'

class Home extends Component {
    constructor(props) {
        super(props)

        this.state = {
                products: [],

               // id: this.props.match.params.id,
              //  productName: '',
               // productPrice: '',
               // description: ''
        }
        this.addProduct = this.addProduct.bind(this);
        this.editProduct = this.editProduct.bind(this);
        this.deleteProduct = this.deleteProduct.bind(this);
        this.cart=this.cart.bind(this);
        this.addToCart = this.addToCart.bind(this);
        this.ProductList=this.ProductList.bind(this);
    }

    componentDidMount(){
        ProductService.getProducts().then((res) => {
            this.setState({products: res.data});
        });
    }

    addProduct(){
        this.props.history.push('/add-product/_add');
    }

    editProduct(id){
        this.props.history.push(`/add-product/${id}`);
    }

    deleteProduct(id){
        ProductService.deleteProduct(id).then( res => {
            this.setState({products: this.state.products.filter(product => product.id !== id)});
        });
    }

    viewProduct(id){
        this.props.history.push(`/view-product/${id}`);
    }

    addCart(id){
        this.props.history.push(`/addcart/${id}`);
    }

    cart(){
        this.props.history.push('/cart');
    }

    addToCart(id){
        this.props.history.push(`/add-cart/${id}`);
    }

    ProductList(){
        this.props.history.push('/products');
    }

    render() {
        return (
            <div>
                 <h2 className="text-center">Home</h2>
                 <div className = "row">
                    <button className="btn btn-primary" onClick={this.ProductList}> Product List</button>
                 </div>
                 <div className = "row">
                    <button className="btn btn-primary" onClick={this.cart}> Cart</button>
                 </div>
                 <br></br>
                 <div className = "row">
                        <table className = "table table-striped table-bordered">

                            <thead>
                                <tr>
                                    <th> Product Name</th>
                                    <th> Product Price</th>
                                    <th> Product Description</th>
                                    <th> Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                {
                                    this.state.products.map(
                                        product => 
                                        <tr key = {product.id}>
                                             <td> { product.productName} </td>   
                                             <td> {product.productPrice}</td>
                                             <td> {product.description}</td>
                                             <td>
                                                <button style={{marginLeft: "10px"}} onClick={ () => this.viewProduct(product.id)} className="btn btn-info">View </button>
                                                 <button style={{marginLeft: "10px"}} onClick={ () => this.addCart(product.id)} className="btn btn-info">Add to Cart </button>
                                             </td>
                                        </tr>
                                    )
                                }
                            </tbody>
                        </table>
                 </div>
            </div>
        )
    }
}

export default Home
