import React from 'react';
import './App.css';
import {BrowserRouter as Router, Route, Switch} from 'react-router-dom'
import HeaderComponent from './components/HeaderComponent';
import FooterComponent from './components/FooterComponent';
import CreateProductComponent from './components/CreateProductComponent';
import ViewProductComponent from './components/ViewProductComponent';
import Cart from './components/Cart';
import CreateCart from './components/CreateCart';
import CreateCartComponent from './components/CreateCartComponent';
import demo from './components/Demo';
import Demo from './components/Demo';
import Home from './components/Home';
import ProductList from './components/ProductList';


function App() {

  return (
    <div>
        <Router>
              <HeaderComponent />
                <div className="container">
                    <Switch> 
                        <Route path = "/" exact component = {Home}></Route>
                        {/* <Route path = "/products" component = {ListProductComponent}></Route> */}
                        <Route path = "/products" component = {ProductList}></Route>
                        <Route path = "/add-product/:id" component = {CreateProductComponent}></Route>
                        <Route path = "/view-product/:id" component = {ViewProductComponent}></Route>
                        <Route path = "/addcart/:id" component = {Demo}></Route>
                        <Route path = "/cart" component = {Cart}></Route>
                        <Route path ="/add-cart/:id" component = {CreateProductComponent}> </Route>

                    </Switch>
                          
                </div>
              <FooterComponent />
        </Router>
    </div>
  );
}

export default App;
